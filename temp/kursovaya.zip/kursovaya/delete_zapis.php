<?php

$mysqli = require __DIR__ . "/database.php";

require __DIR__ . '/user.php';

$sql = sprintf(
    "DELETE FROM `zayavka` WHERE `zayavka`.`id`= '%s'",
    $mysqli->real_escape_string($_GET["id"])
);
$result = $mysqli->query($sql);

header("Location: lk.php");
exit;