<?php
$mysqli = require __DIR__ . "/database.php";

require __DIR__ . '/user.php';

require __DIR__ . '/header.php';

if (isset($_POST['category_id'])) {

	$sql = "SELECT * FROM prais_list WHERE id={$_POST["category_id"]}";
	$result = $mysqli->query($sql);
	$usluga = $result->fetch_assoc(); // получаем услугу

	$dts = $_POST["trip-start"] . " " . $_POST["time"] . ':00'; // время начала услуги
	$dtf = date('Y-m-d H:i:s', strtotime($dts) + (int)$usluga['time'] * 60);

	if ($dts < date('Y-m-d H:i:s')) {
		$error = "Запись на прошедшие периоды недоступна!";
	} else {
		$sql = "SELECT COUNT(*) FROM zayavka WHERE `id`<>'{$_GET['id']}' AND mastera_id='{$_POST["mastera_id"]}' AND ((vremya_nachala<='{$dts}' AND vremya_okonchania >= '{$dts}') OR (vremya_nachala<='{$dtf}' AND vremya_okonchania >= '{$dtf}')) "; // наложение времени выбранное,с тем которое заняли
		$result = $mysqli->query($sql);
		$count = (int)$result->fetch_row()[0];
		if ($count > 0) {
			$error = "Данное время занято! Выбирите другое время!";
		} else {
			$sql = "UPDATE `zayavka` SET `prais_id` = '{$_POST["category_id"]}',vremya_nachala='{$dts}',vremya_okonchania='{$dtf}' WHERE `zayavka`.`id` = '{$_GET['id']}'";
			$mysqli->query($sql);
			header("location: lk.php");
			exit;
		}
	}
}

$sql = sprintf(
	"SELECT * FROM `zayavka` WHERE `zayavka`.`id`= '%s'",
	$mysqli->real_escape_string($_GET["id"])
);
$result = $mysqli->query($sql);
$zapis = $result->fetch_assoc();
?>

<div class="wrapper about">
	<div class="text-center">
		<?php if (isset($error)) : ?>
			<h3><?= $error; ?></h3>
		<?php endif; ?>
		<h2>Выберите услугу</h2>
		<form action="" method="post" class="flex-col form gap-1 text-left">
			<input type="hidden" name="mastera_id" value="<?= $zapis['mastera_id'] ?>">
			<div class="flex justify-between quote">
				<span>Услуга</span>
				<select class="form-block__input" name="category_id">
					<?php
					$sql = sprintf("SELECT * FROM prais_list WHERE mastera_id='{$zapis['mastera_id']}'");
					$result = $mysqli->query($sql);
					$prais_list = $result->fetch_all();
					?>
					<?php foreach ($prais_list as $item) : ?>
						<option value="<?= $item[0]; ?>" <?= $zapis['prais_id'] === $item[0] ? 'selected' : '' ?>><?= $item[1]; ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="flex justify-between quote">
				<span>Дата</span>
				<input type="date" id="start" name="trip-start" class="form-block__input" value="<?= explode(' ', $zapis['vremya_nachala'])[0]; ?>" />
			</div>
			<div class="flex justify-between quote">
				<span>Время:</span>
				<input type="time" id="time" name="time" class="form-block__input" value="<?= substr(explode(' ', $zapis['vremya_nachala'])[1], 0, 5); ?>" />
			</div>
			<button class="link button" type="submit">Сохранить</button>
		</form>
	</div>
</div>

<?php
require __DIR__ . '/footer.php';
?>