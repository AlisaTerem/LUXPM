<?php
$mysqli = require __DIR__ . "/database.php";
require __DIR__ . '/header.php';
?>





<div class="wrapper about">
	<div class="text-center">
		<?php if (!isset($_GET['master_id'])) : ?>
			<h2>Рекомендации мастеров салона LUX PM</h2>
			<div class="flex">
				<div class="quote link w-auto">
					<span>Рекомендации мастера-парикмахера</span>
					<a href="pamyatkaP.php">
						<img src="img\A3.jpg" class="image">
					</a>
				</div>
				<div class="quote link w-auto">
					<span>Рекомендации мастера Перманентного Макияжа</span>
					<a href="pamyatkaPM.php">
						<img src="img\evgenia1.jpg" class="image">
					</a>
				</div>
			</div>
			</div>
			<?php endif; ?>

<?php
require __DIR__.'/footer.php'; 
?>
           


			

