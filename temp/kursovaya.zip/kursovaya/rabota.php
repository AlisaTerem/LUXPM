<?php
$mysqli = require __DIR__ . "/database.php";
require __DIR__ . '/header.php';
?>





<div class="wrapper about">
	<div class="text-center">
		<?php if (!isset($_GET['master_id'])) : ?>
			<h2>Работы наших специалистов</h2>
			<div class="flex">
				<div class="quote link w-auto">
					<span>Работы мастера ПМ Евгении</span>
					<a href="rabotaE.php">
						<img src="img\E3.jpg" class="image">
					</a>
				</div>
				<div class="quote link w-auto">
					<span>Работы парикмахера Алисы</span>
					<a href="rabotaA.php">
						<img src="img\AV1.jpg" class="image">
					</a>
				</div>
			</div>
			</div>
			<?php endif; ?>

<?php
require __DIR__.'/footer.php'; 
?>
           


			

