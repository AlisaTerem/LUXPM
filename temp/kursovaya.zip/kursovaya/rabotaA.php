<?php
require __DIR__ . '/header.php';
?>

<div class="wrapper portfolio">
    <div class="portfolio-section">
        <h2>Работы мастера Алисы</h2>
        <div class="grid">
            <div class="portfolio-card flex-col">
                <img src="img\rabota1.jpg" class="portfolio-image">
                <span>Окрашивание блонд</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\Arina.jpg" class="portfolio-image">
                <span>Окрашивание в один тон</span>
            </div>
            
            <div class="portfolio-card flex-col">
                <img src="img\rabota3.jpg" class="portfolio-image">
                <span>Креативное окрашивание </span>
            </div>
            
            <div class="portfolio-card flex-col">
                <img src="img\rabota4.jpg" class="portfolio-image">
                <span>Укладка на длинные волосы</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota5.jpg" class="portfolio-image">
                <span>Конкурсная работа</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota6.jpg" class="portfolio-image">
                <span>Конкурсная работа</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota7.jpg" class="portfolio-image">
                <span>Свадебная прическа</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\Q.jpg" class="portfolio-image">
                <span>Сложное окрашивание </span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\U.jpg" class="portfolio-image">
                <span>Сложное окрашивание </span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\PK.jpg" class="portfolio-image">
                <span>Детское креативное окрашивание</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\anna.jpg" class="portfolio-image">
                <span>Окрашивание Airtouch</span>
            </div>
            
            <div class="portfolio-card flex-col">
                <img src="img\S.jpg" class="portfolio-image">
                <span>Окрашивание в один тон</span>
            </div>
        </div>
    </div>

    
        
</div>

<?php
require __DIR__.'/footer.php'; 
?>