<?php
require __DIR__ . '/header.php';
?>

<div class="wrapper portfolio">
    
    <div>
        <h2>Работы мастера Евгении</h2>
        <div class="grid">
            <div class="portfolio-card flex-col">
                <img src="img\rabota10.jpg" class="portfolio-image">
                <span>Межрисничная растушевка</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota11.jpg" class="portfolio-image">
                <span>Напыление бровей</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota12.jpg" class="portfolio-image">
                <span>ПМ губ</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota13.jpg" class="portfolio-image">
                <span>ПМ бровей</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota14.jpg" class="portfolio-image">
                <span>Межрисничная растушевка</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabota15.jpg" class="portfolio-image">
                <span>ПМ бровей</span>
            </div>

            <div class="portfolio-card flex-col">
                <img src="img\rabotaE16.jpg" class="portfolio-image">
                <span>Удаление тату</span>
            </div>
        </div>
    </div>
</div>

<?php
require __DIR__.'/footer.php'; 
?>