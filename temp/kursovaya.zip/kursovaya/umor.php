<?php
require __DIR__ . '/header.php';
?>
<div class="wrapper portfolio">
    <div class="portfolio-section">
        <h2>Работы мастера Алисы</h2>
        <div class="grid">
            <div class="portfolio-card flex-col">
                <video src="mp4\S1.MP3" class="portfolio-image">
                <span>Окрашивание блонд</span>
            </div>

            
        </div>
    </div>

   
</div>

<?php
require __DIR__.'/footer.php'; 
?>